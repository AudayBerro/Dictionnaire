package fichierCreer;

import java.io.Serializable;

public class Test1 implements Serializable{
	private final String nom;
	private final String prenom;
	private final int age;

	public Test1(String nom,String prenom,int age){
		 this.nom = nom;
		 this.prenom = prenom;
		 this.age = age;
	}

	public String toString(){
		return getClass().getName()+"[nom="+nom+",prenom="+prenom+",age="+age+"]";
	}

	public boolean equals(Object otherObject){
		if(this==otherObject) return true;
		if(otherObject==null) return false;
		if(!(otherObject instanceof Test1)) return false;
		Test1 other=(Test1) otherObject;
		return nom==other.nom && prenom==other.prenom && age==other.age;
	}

	public int hashCode(){
		int resultat=0;
		resultat=31;
		resultat=97*resultat+(this.nom != null ?this.nom.hashCode():0);
		resultat=97*resultat+(this.prenom != null ?this.prenom.hashCode():0);
		return resultat;
	}
}