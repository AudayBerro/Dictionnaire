package fichierCreer;

import java.io.Serializable;

public class Test2 extends Test1 implements Serializable{

	private final int poids;
	private final int taille;
	private final int masse;

	public Test2(String nom,String prenom,int age,int poids,int taille,int masse){
		super(nom,prenom,age);
		 this.poids = poids;
		 this.taille = taille;
		 this.masse = masse;
	}

	public String toString(){
		return super.toString()+"[poids="+poids+",taille="+taille+",masse="+masse+"]";
	}

	public boolean equals(Object otherObject){
		if(!super.equals(otherObject)) return false;
		if(otherObject==null) return false;
		if(!(otherObject instanceof Test2)) return false;
		Test2 other=(Test2) otherObject;
		return poids==other.poids && taille==other.taille && masse==other.masse;
	}

	public int hashCode(){
		int resultat=0;
		resultat=super.hashCode();
		return resultat;
	}
}